﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace form_submission.Models
{
    public class Login5
    {
        public string Username {  get; set; }
        public string Id { get; set; }
        public string Gender { get; set; }
        public string Profession { get; set; }
        public string Hobbies { get; set; }
    }
}