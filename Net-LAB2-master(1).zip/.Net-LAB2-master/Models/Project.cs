﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Company_website.Models
{
    public class Project
    {
        public string Name { get; set; }
        public string Auther { get; set; }
        public string Email { get; set; }
    }
}